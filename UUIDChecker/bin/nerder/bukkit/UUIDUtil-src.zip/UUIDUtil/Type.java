package nerder.bukkit.UUIDUtil;

public enum Type {
	KICK, BAN;
}
